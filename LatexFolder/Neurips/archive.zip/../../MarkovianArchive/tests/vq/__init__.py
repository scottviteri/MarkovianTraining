"""
Tests for Vector Quantization module
""" 