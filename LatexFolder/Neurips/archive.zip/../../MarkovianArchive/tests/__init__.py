"""
Test suite for MarkovianTraining
""" 