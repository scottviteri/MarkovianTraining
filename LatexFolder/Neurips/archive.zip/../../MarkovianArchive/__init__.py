"""
Markovian Training with Vector Quantization
 
Top-level package module.
""" 